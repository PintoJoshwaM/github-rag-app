import httpx
from typing import Optional, List, Dict, Any
from core.config import settings
from core.logger import logger


class GitHubService:
    """Interact with the GitHub REST API."""

    def __init__(self):
        self.base_url = settings.GITHUB_API_BASE
        self.headers = {
            "Authorization": f"Bearer {settings.GITHUB_TOKEN}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    async def _get(self, path: str, params: Dict = None) -> Any:
        async with httpx.AsyncClient(headers=self.headers, timeout=30) as client:
            resp = await client.get(f"{self.base_url}{path}", params=params)
            resp.raise_for_status()
            return resp.json()

    # ── Repositories ──────────────────────────────────────────────────────────
    async def get_repo(self, owner: str, repo: str) -> Dict:
        return await self._get(f"/repos/{owner}/{repo}")

    async def list_repos(self, owner: str, org: bool = False) -> List[Dict]:
        path = f"/orgs/{owner}/repos" if org else f"/users/{owner}/repos"
        return await self._get(path, params={"per_page": 100, "sort": "updated"})

    # ── Issues ─────────────────────────────────────────────────────────────────
    async def list_issues(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        labels: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict]:
        params = {"state": state, "per_page": min(limit, 100)}
        if labels:
            params["labels"] = labels
        return await self._get(f"/repos/{owner}/{repo}/issues", params=params)

    async def get_issue(self, owner: str, repo: str, number: int) -> Dict:
        return await self._get(f"/repos/{owner}/{repo}/issues/{number}")

    async def list_issue_comments(self, owner: str, repo: str, number: int) -> List[Dict]:
        return await self._get(f"/repos/{owner}/{repo}/issues/{number}/comments")

    # ── Pull Requests ──────────────────────────────────────────────────────────
    async def list_prs(
        self, owner: str, repo: str, state: str = "open", limit: int = 30
    ) -> List[Dict]:
        return await self._get(
            f"/repos/{owner}/{repo}/pulls",
            params={"state": state, "per_page": min(limit, 100)},
        )

    async def get_pr(self, owner: str, repo: str, number: int) -> Dict:
        return await self._get(f"/repos/{owner}/{repo}/pulls/{number}")

    async def get_pr_files(self, owner: str, repo: str, number: int) -> List[Dict]:
        return await self._get(f"/repos/{owner}/{repo}/pulls/{number}/files")

    # ── Code / Contents ────────────────────────────────────────────────────────
    async def get_file_content(self, owner: str, repo: str, path: str, ref: str = "HEAD") -> str:
        import base64
        data = await self._get(
            f"/repos/{owner}/{repo}/contents/{path}", params={"ref": ref}
        )
        if data.get("encoding") == "base64":
            return base64.b64decode(data["content"]).decode("utf-8", errors="replace")
        return data.get("content", "")

    async def list_tree(self, owner: str, repo: str, ref: str = "HEAD") -> List[Dict]:
        data = await self._get(
            f"/repos/{owner}/{repo}/git/trees/{ref}", params={"recursive": "1"}
        )
        return [item for item in data.get("tree", []) if item["type"] == "blob"]

    # ── Actions ────────────────────────────────────────────────────────────────
    async def list_workflows(self, owner: str, repo: str) -> List[Dict]:
        data = await self._get(f"/repos/{owner}/{repo}/actions/workflows")
        return data.get("workflows", [])

    async def list_workflow_runs(
        self, owner: str, repo: str, workflow_id: str, limit: int = 10
    ) -> List[Dict]:
        data = await self._get(
            f"/repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
            params={"per_page": limit},
        )
        return data.get("workflow_runs", [])

    async def get_run_logs_url(self, owner: str, repo: str, run_id: int) -> str:
        data = await self._get(f"/repos/{owner}/{repo}/actions/runs/{run_id}")
        return data.get("logs_url", "")

    async def list_artifacts(self, owner: str, repo: str) -> List[Dict]:
        data = await self._get(f"/repos/{owner}/{repo}/actions/artifacts")
        return data.get("artifacts", [])

    # ── Search ─────────────────────────────────────────────────────────────────
    async def search_code(self, query: str, owner: str, repo: str) -> List[Dict]:
        data = await self._get(
            "/search/code",
            params={"q": f"{query} repo:{owner}/{repo}", "per_page": 20},
        )
        return data.get("items", [])

    async def search_issues(self, query: str, owner: str, repo: str) -> List[Dict]:
        data = await self._get(
            "/search/issues",
            params={"q": f"{query} repo:{owner}/{repo}", "per_page": 20},
        )
        return data.get("items", [])


github_service = GitHubService()
