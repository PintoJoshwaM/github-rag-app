import chromadb
from chromadb.config import Settings as ChromaSettings
import httpx
import json
from typing import List, Dict, Any
from core.config import settings
from core.logger import logger
from services.github_service import github_service


class IngestService:
    """Chunk GitHub content and store embeddings in ChromaDB."""

    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIR,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=settings.COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    # ── Embedding via Ollama ───────────────────────────────────────────────────
    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        embeddings = []
        async with httpx.AsyncClient(timeout=60) as client:
            for text in texts:
                resp = await client.post(
                    f"{settings.OLLAMA_BASE_URL}/api/embeddings",
                    json={"model": settings.EMBEDDING_MODEL, "prompt": text},
                )
                resp.raise_for_status()
                embeddings.append(resp.json()["embedding"])
        return embeddings

    # ── Chunking ───────────────────────────────────────────────────────────────
    def chunk_text(self, text: str, source: str, metadata: Dict) -> List[Dict]:
        size = settings.CHUNK_SIZE
        overlap = settings.CHUNK_OVERLAP
        chunks = []
        start = 0
        idx = 0
        while start < len(text):
            end = start + size
            chunk = text[start:end]
            chunks.append(
                {
                    "text": chunk,
                    "id": f"{source}_chunk_{idx}",
                    "metadata": {**metadata, "source": source, "chunk_index": idx},
                }
            )
            idx += 1
            start += size - overlap
        return chunks

    # ── Ingest helpers ─────────────────────────────────────────────────────────
    async def _upsert_chunks(self, chunks: List[Dict]):
        if not chunks:
            return
        texts = [c["text"] for c in chunks]
        embeddings = await self.embed_texts(texts)
        self.collection.upsert(
            ids=[c["id"] for c in chunks],
            embeddings=embeddings,
            documents=texts,
            metadatas=[c["metadata"] for c in chunks],
        )
        logger.info(f"Upserted {len(chunks)} chunks into ChromaDB")

    # ── Public ingest methods ──────────────────────────────────────────────────
    async def ingest_repo_readme(self, owner: str, repo: str):
        try:
            content = await github_service.get_file_content(owner, repo, "README.md")
            chunks = self.chunk_text(
                content,
                source=f"{owner}/{repo}/README.md",
                metadata={"owner": owner, "repo": repo, "type": "readme"},
            )
            await self._upsert_chunks(chunks)
        except Exception as e:
            logger.warning(f"Could not ingest README for {owner}/{repo}: {e}")

    async def ingest_issues(self, owner: str, repo: str, state: str = "open", limit: int = 50):
        issues = await github_service.list_issues(owner, repo, state=state, limit=limit)
        all_chunks = []
        for issue in issues:
            text = f"Issue #{issue['number']}: {issue['title']}\n\n{issue.get('body') or ''}"
            chunks = self.chunk_text(
                text,
                source=f"{owner}/{repo}/issues/{issue['number']}",
                metadata={
                    "owner": owner,
                    "repo": repo,
                    "type": "issue",
                    "number": issue["number"],
                    "state": issue["state"],
                    "url": issue["html_url"],
                },
            )
            all_chunks.extend(chunks)
        await self._upsert_chunks(all_chunks)

    async def ingest_pull_requests(self, owner: str, repo: str, state: str = "open", limit: int = 30):
        prs = await github_service.list_prs(owner, repo, state=state, limit=limit)
        all_chunks = []
        for pr in prs:
            text = f"PR #{pr['number']}: {pr['title']}\n\n{pr.get('body') or ''}"
            chunks = self.chunk_text(
                text,
                source=f"{owner}/{repo}/pulls/{pr['number']}",
                metadata={
                    "owner": owner,
                    "repo": repo,
                    "type": "pull_request",
                    "number": pr["number"],
                    "state": pr["state"],
                    "url": pr["html_url"],
                },
            )
            all_chunks.extend(chunks)
        await self._upsert_chunks(all_chunks)

    async def ingest_code_files(
        self, owner: str, repo: str, extensions: List[str] = None, max_files: int = 50
    ):
        if extensions is None:
            extensions = [".py", ".ts", ".js", ".go", ".java", ".md"]
        tree = await github_service.list_tree(owner, repo)
        filtered = [
            f for f in tree if any(f["path"].endswith(ext) for ext in extensions)
        ][:max_files]

        all_chunks = []
        for file_info in filtered:
            try:
                content = await github_service.get_file_content(owner, repo, file_info["path"])
                chunks = self.chunk_text(
                    content,
                    source=f"{owner}/{repo}/{file_info['path']}",
                    metadata={
                        "owner": owner,
                        "repo": repo,
                        "type": "code",
                        "file_path": file_info["path"],
                    },
                )
                all_chunks.extend(chunks)
            except Exception as e:
                logger.warning(f"Skipping {file_info['path']}: {e}")
        await self._upsert_chunks(all_chunks)

    async def ingest_workflows(self, owner: str, repo: str):
        workflows = await github_service.list_workflows(owner, repo)
        all_chunks = []
        for wf in workflows:
            # Workflow YAML is stored in the repo at wf["path"]
            try:
                content = await github_service.get_file_content(owner, repo, wf["path"])
                chunks = self.chunk_text(
                    content,
                    source=f"{owner}/{repo}/{wf['path']}",
                    metadata={
                        "owner": owner,
                        "repo": repo,
                        "type": "workflow",
                        "workflow_name": wf["name"],
                        "workflow_id": wf["id"],
                    },
                )
                all_chunks.extend(chunks)
            except Exception as e:
                logger.warning(f"Skipping workflow {wf['name']}: {e}")
        await self._upsert_chunks(all_chunks)

    async def ingest_full_repo(self, owner: str, repo: str):
        logger.info(f"Starting full ingest for {owner}/{repo}")
        await self.ingest_repo_readme(owner, repo)
        await self.ingest_issues(owner, repo, state="all", limit=100)
        await self.ingest_pull_requests(owner, repo, state="all", limit=50)
        await self.ingest_code_files(owner, repo)
        await self.ingest_workflows(owner, repo)
        logger.info(f"Full ingest complete for {owner}/{repo}")

    # ── Query ──────────────────────────────────────────────────────────────────
    async def query(self, question: str, filter_meta: Dict = None, top_k: int = None) -> List[Dict]:
        top_k = top_k or settings.TOP_K_RESULTS
        embeddings = await self.embed_texts([question])
        kwargs = {
            "query_embeddings": embeddings,
            "n_results": top_k,
            "include": ["documents", "metadatas", "distances"],
        }
        if filter_meta:
            kwargs["where"] = filter_meta
        results = self.collection.query(**kwargs)

        docs = []
        for i, doc in enumerate(results["documents"][0]):
            docs.append(
                {
                    "content": doc,
                    "metadata": results["metadatas"][0][i],
                    "score": 1 - results["distances"][0][i],
                }
            )
        return docs


ingest_service = IngestService()
