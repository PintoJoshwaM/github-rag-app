import httpx
import json
from typing import AsyncIterator, List, Dict
from core.config import settings
from core.logger import logger
from services.ingest_service import ingest_service


SYSTEM_PROMPT = """You are an expert GitHub assistant with deep knowledge of software development.
You answer questions based on the repository context provided. When answering:
- Reference specific issues, PRs, files, or workflows by their numbers/paths
- Be concise and technically accurate
- If the context doesn't contain enough info, say so clearly
- Format code snippets with markdown code blocks"""


class RAGService:
    """Retrieve context and generate answers with Llama via Ollama."""

    def _build_prompt(self, question: str, context_docs: List[Dict]) -> str:
        context_parts = []
        for i, doc in enumerate(context_docs, 1):
            meta = doc["metadata"]
            source_label = meta.get("source", f"doc_{i}")
            context_parts.append(f"[{i}] Source: {source_label}\n{doc['content']}")

        context = "\n\n---\n\n".join(context_parts)
        return f"""Context from GitHub repository:

{context}

---

Question: {question}

Answer based on the context above:"""

    async def answer(
        self,
        question: str,
        owner: str,
        repo: str,
        content_types: List[str] = None,
    ) -> Dict:
        # Build filter
        where_filter = {"owner": owner, "repo": repo}

        # Retrieve relevant chunks
        docs = await ingest_service.query(question, filter_meta=where_filter)

        # Optional type filter (post-retrieval)
        if content_types:
            docs = [d for d in docs if d["metadata"].get("type") in content_types]

        if not docs:
            return {
                "answer": "No relevant context found in the indexed repository. Try re-ingesting or rephrasing your question.",
                "sources": [],
            }

        prompt = self._build_prompt(question, docs)

        # Call Ollama
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{settings.OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": settings.LLAMA_MODEL,
                    "prompt": prompt,
                    "system": SYSTEM_PROMPT,
                    "stream": False,
                    "options": {
                        "temperature": settings.LLAMA_TEMPERATURE,
                        "num_predict": settings.LLAMA_MAX_TOKENS,
                    },
                },
            )
            resp.raise_for_status()
            data = resp.json()
            answer_text = data.get("response", "")

        sources = [
            {
                "source": d["metadata"].get("source"),
                "type": d["metadata"].get("type"),
                "url": d["metadata"].get("url"),
                "score": round(d["score"], 3),
            }
            for d in docs
        ]

        return {"answer": answer_text, "sources": sources}

    async def stream_answer(
        self,
        question: str,
        owner: str,
        repo: str,
    ) -> AsyncIterator[str]:
        where_filter = {"owner": owner, "repo": repo}
        docs = await ingest_service.query(question, filter_meta=where_filter)

        if not docs:
            yield "data: " + json.dumps({"token": "No relevant context found.", "done": True}) + "\n\n"
            return

        prompt = self._build_prompt(question, docs)
        sources = [
            {
                "source": d["metadata"].get("source"),
                "type": d["metadata"].get("type"),
                "url": d["metadata"].get("url"),
                "score": round(d["score"], 3),
            }
            for d in docs
        ]

        async with httpx.AsyncClient(timeout=180) as client:
            async with client.stream(
                "POST",
                f"{settings.OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": settings.LLAMA_MODEL,
                    "prompt": prompt,
                    "system": SYSTEM_PROMPT,
                    "stream": True,
                    "options": {
                        "temperature": settings.LLAMA_TEMPERATURE,
                        "num_predict": settings.LLAMA_MAX_TOKENS,
                    },
                },
            ) as resp:
                async for line in resp.aiter_lines():
                    if line:
                        try:
                            chunk = json.loads(line)
                            token = chunk.get("response", "")
                            done = chunk.get("done", False)
                            payload = {"token": token, "done": done}
                            if done:
                                payload["sources"] = sources
                            yield "data: " + json.dumps(payload) + "\n\n"
                        except json.JSONDecodeError:
                            continue


rag_service = RAGService()
