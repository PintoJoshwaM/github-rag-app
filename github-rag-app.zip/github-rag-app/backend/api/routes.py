from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from typing import List, Optional
import asyncio

from models.schemas import (
    IngestRequest, IngestResponse,
    QueryRequest, QueryResponse, SourceDoc,
    WorkflowSummary, WorkflowRunSummary,
    ContentType,
)
from services.github_service import github_service
from services.ingest_service import ingest_service
from services.rag_service import rag_service
from core.logger import logger

router = APIRouter()


# ── Ingest ─────────────────────────────────────────────────────────────────────

@router.post("/ingest", response_model=IngestResponse, tags=["ingest"])
async def ingest_repo(body: IngestRequest, background_tasks: BackgroundTasks):
    """
    Kick off ingestion of GitHub content into the vector store.
    Runs in the background so the response is immediate.
    """
    async def _run():
        try:
            if not body.content_types:
                await ingest_service.ingest_full_repo(body.owner, body.repo)
            else:
                tasks = []
                for ct in body.content_types:
                    if ct == ContentType.readme:
                        tasks.append(ingest_service.ingest_repo_readme(body.owner, body.repo))
                    elif ct == ContentType.issue:
                        tasks.append(ingest_service.ingest_issues(body.owner, body.repo))
                    elif ct == ContentType.pull_request:
                        tasks.append(ingest_service.ingest_pull_requests(body.owner, body.repo))
                    elif ct == ContentType.code:
                        tasks.append(ingest_service.ingest_code_files(body.owner, body.repo))
                    elif ct == ContentType.workflow:
                        tasks.append(ingest_service.ingest_workflows(body.owner, body.repo))
                await asyncio.gather(*tasks)
        except Exception as e:
            logger.error(f"Ingest failed for {body.owner}/{body.repo}: {e}")

    background_tasks.add_task(_run)
    return IngestResponse(
        message="Ingestion started in background",
        owner=body.owner,
        repo=body.repo,
    )


# ── Query / RAG ────────────────────────────────────────────────────────────────

@router.post("/query", tags=["rag"])
async def query_repo(body: QueryRequest):
    """
    Ask a question about an ingested repository.
    Supports streaming (SSE) when `stream=true`.
    """
    if body.stream:
        return StreamingResponse(
            rag_service.stream_answer(body.question, body.owner, body.repo),
            media_type="text/event-stream",
        )

    result = await rag_service.answer(
        body.question, body.owner, body.repo,
        content_types=[ct.value for ct in body.content_types] if body.content_types else None,
    )
    return QueryResponse(
        answer=result["answer"],
        sources=[SourceDoc(**s) for s in result["sources"]],
    )


# ── Repository Info ────────────────────────────────────────────────────────────

@router.get("/repos/{owner}/{repo}", tags=["github"])
async def get_repo(owner: str, repo: str):
    try:
        return await github_service.get_repo(owner, repo)
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/repos/{owner}/{repo}/issues", tags=["github"])
async def list_issues(
    owner: str,
    repo: str,
    state: str = "open",
    labels: Optional[str] = None,
    limit: int = 50,
):
    return await github_service.list_issues(owner, repo, state=state, labels=labels, limit=limit)


@router.get("/repos/{owner}/{repo}/pulls", tags=["github"])
async def list_prs(owner: str, repo: str, state: str = "open", limit: int = 30):
    return await github_service.list_prs(owner, repo, state=state, limit=limit)


@router.get("/repos/{owner}/{repo}/search/code", tags=["github"])
async def search_code(owner: str, repo: str, q: str):
    return await github_service.search_code(q, owner, repo)


@router.get("/repos/{owner}/{repo}/search/issues", tags=["github"])
async def search_issues(owner: str, repo: str, q: str):
    return await github_service.search_issues(q, owner, repo)


# ── GitHub Actions ─────────────────────────────────────────────────────────────

@router.get("/repos/{owner}/{repo}/actions/workflows", response_model=List[WorkflowSummary], tags=["actions"])
async def list_workflows(owner: str, repo: str):
    workflows = await github_service.list_workflows(owner, repo)
    return [
        WorkflowSummary(
            id=wf["id"],
            name=wf["name"],
            state=wf.get("state", ""),
            path=wf.get("path", ""),
            url=wf.get("html_url", ""),
        )
        for wf in workflows
    ]


@router.get(
    "/repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs",
    response_model=List[WorkflowRunSummary],
    tags=["actions"],
)
async def list_workflow_runs(owner: str, repo: str, workflow_id: str, limit: int = 10):
    runs = await github_service.list_workflow_runs(owner, repo, workflow_id, limit=limit)
    return [
        WorkflowRunSummary(
            id=r["id"],
            name=r.get("name"),
            status=r.get("status"),
            conclusion=r.get("conclusion"),
            created_at=r["created_at"],
            updated_at=r["updated_at"],
            html_url=r["html_url"],
        )
        for r in runs
    ]


@router.get("/repos/{owner}/{repo}/actions/artifacts", tags=["actions"])
async def list_artifacts(owner: str, repo: str):
    return await github_service.list_artifacts(owner, repo)
