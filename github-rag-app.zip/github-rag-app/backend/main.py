from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from contextlib import asynccontextmanager
import uvicorn

from api.routes import router
from core.config import settings
from core.logger import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting GitHub RAG App...")
    yield
    logger.info("Shutting down GitHub RAG App...")


app = FastAPI(
    title="GitHub RAG App",
    description="RAG-powered GitHub assistant using Llama",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/health")
async def health_check():
    return {"status": "ok", "version": "1.0.0"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
