from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum


class ContentType(str, Enum):
    readme = "readme"
    issue = "issue"
    pull_request = "pull_request"
    code = "code"
    workflow = "workflow"


# ── Ingest ─────────────────────────────────────────────────────────────────────

class IngestRequest(BaseModel):
    owner: str = Field(..., description="GitHub owner or org")
    repo: str = Field(..., description="Repository name")
    content_types: Optional[List[ContentType]] = Field(
        None,
        description="Specific content types to ingest; omit for full ingest",
    )


class IngestResponse(BaseModel):
    message: str
    owner: str
    repo: str


# ── Query ──────────────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=1000)
    owner: str
    repo: str
    content_types: Optional[List[ContentType]] = None
    stream: bool = False


class SourceDoc(BaseModel):
    source: Optional[str]
    type: Optional[str]
    url: Optional[str]
    score: float


class QueryResponse(BaseModel):
    answer: str
    sources: List[SourceDoc]


# ── GitHub Actions ────────────────────────────────────────────────────────────

class WorkflowRunStatus(str, Enum):
    queued = "queued"
    in_progress = "in_progress"
    completed = "completed"


class WorkflowSummary(BaseModel):
    id: int
    name: str
    state: str
    path: str
    url: str


class WorkflowRunSummary(BaseModel):
    id: int
    name: Optional[str]
    status: Optional[str]
    conclusion: Optional[str]
    created_at: str
    updated_at: str
    html_url: str
