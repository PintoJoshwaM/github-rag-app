from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # App
    APP_NAME: str = "GitHub RAG App"
    DEBUG: bool = False
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # GitHub
    GITHUB_TOKEN: str = ""
    GITHUB_API_BASE: str = "https://api.github.com"

    # Llama / Ollama
    LLAMA_MODEL: str = "llama3.2"
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    LLAMA_TEMPERATURE: float = 0.1
    LLAMA_MAX_TOKENS: int = 2048

    # Vector Store (ChromaDB)
    CHROMA_PERSIST_DIR: str = "./data/chroma"
    COLLECTION_NAME: str = "github_rag"

    # Embedding
    EMBEDDING_MODEL: str = "nomic-embed-text"

    # RAG
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    TOP_K_RESULTS: int = 5

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
