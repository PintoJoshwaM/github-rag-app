# GitHub RAG App

A Retrieval-Augmented Generation (RAG) system that lets you ask natural-language questions about any GitHub repository — issues, PRs, code, and Actions workflows — powered by **Llama** running locally via Ollama.

---

## Architecture

```
GitHub API
    │
    ▼
Ingest Service ──► ChromaDB (vector store)
                        │
User Question           │  retrieve top-K chunks
    │                   ▼
    └──────────► RAG Service ──► Ollama (Llama 3.2)
                                      │
                                      ▼
                                   Answer + Sources
```

## Stack

| Layer | Technology |
|---|---|
| Backend API | FastAPI (Python 3.11) |
| AI / LLM | Llama 3.2 via Ollama |
| Embeddings | nomic-embed-text via Ollama |
| Vector Store | ChromaDB (persistent) |
| GitHub data | GitHub REST API v3 |
| CI/CD | GitHub Actions |
| Containerisation | Docker + Docker Compose |

---

## Quick Start

### 1. Prerequisites

- Docker & Docker Compose  
- A GitHub Personal Access Token (classic or fine-grained)

### 2. Clone & configure

```bash
git clone https://github.com/your-org/github-rag-app
cd github-rag-app
cp backend/.env.example backend/.env
# Edit backend/.env and set GITHUB_TOKEN
```

### 3. Start the stack

```bash
docker compose up --build
```

This will:
- Build the FastAPI backend
- Pull and start Ollama
- Automatically pull `llama3.2` and `nomic-embed-text` models

### 4. Ingest a repository

```bash
curl -X POST http://localhost:8000/api/v1/ingest \
  -H "Content-Type: application/json" \
  -d '{"owner": "fastapi", "repo": "fastapi"}'
```

Ingest runs in the background. Wait ~30–60 seconds for a medium repo.

### 5. Ask questions

```bash
curl -X POST http://localhost:8000/api/v1/query \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What are the most common open issues?",
    "owner": "fastapi",
    "repo": "fastapi"
  }'
```

#### Streaming response (SSE)

```bash
curl -X POST http://localhost:8000/api/v1/query \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Explain the dependency injection system",
    "owner": "fastapi",
    "repo": "fastapi",
    "stream": true
  }'
```

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/ingest` | Ingest repo into vector store |
| `POST` | `/api/v1/query` | RAG query (+ streaming) |
| `GET` | `/api/v1/repos/{owner}/{repo}` | Repo metadata |
| `GET` | `/api/v1/repos/{owner}/{repo}/issues` | List issues |
| `GET` | `/api/v1/repos/{owner}/{repo}/pulls` | List pull requests |
| `GET` | `/api/v1/repos/{owner}/{repo}/search/code` | Search code |
| `GET` | `/api/v1/repos/{owner}/{repo}/actions/workflows` | List workflows |
| `GET` | `/api/v1/repos/{owner}/{repo}/actions/workflows/{id}/runs` | Workflow run history |

Interactive docs: **http://localhost:8000/docs**

---

## Ingest Options

You can ingest specific content types:

```json
{
  "owner": "vercel",
  "repo": "next.js",
  "content_types": ["readme", "issue", "code"]
}
```

Available types: `readme`, `issue`, `pull_request`, `code`, `workflow`

---

## GitHub Actions Integration

### CI Pipeline (`.github/workflows/ci.yml`)
Runs on every push/PR: linting, tests, and Docker build.

### Auto-Ingest (`.github/workflows/auto-ingest.yml`)
Automatically triggers a re-ingest whenever code, issues, or PRs change.

**Required secrets:**
- `RAG_BACKEND_URL` — public URL of your deployed backend
- `RAG_API_KEY` — optional API key for auth

---

## Configuration

All settings are in `backend/.env`:

| Variable | Default | Description |
|---|---|---|
| `GITHUB_TOKEN` | — | GitHub PAT (required) |
| `LLAMA_MODEL` | `llama3.2` | Ollama model name |
| `EMBEDDING_MODEL` | `nomic-embed-text` | Embedding model |
| `CHUNK_SIZE` | `1000` | Characters per chunk |
| `CHUNK_OVERLAP` | `200` | Overlap between chunks |
| `TOP_K_RESULTS` | `5` | Chunks retrieved per query |

---

## Local Development (without Docker)

```bash
# Install Ollama: https://ollama.com
ollama pull llama3.2
ollama pull nomic-embed-text

cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # fill in GITHUB_TOKEN

uvicorn main:app --reload
```

---

## Project Structure

```
github-rag-app/
├── backend/
│   ├── main.py              # FastAPI app entry point
│   ├── core/
│   │   ├── config.py        # Pydantic settings
│   │   └── logger.py
│   ├── api/
│   │   └── routes.py        # All HTTP endpoints
│   ├── models/
│   │   └── schemas.py       # Request/response models
│   ├── services/
│   │   ├── github_service.py  # GitHub API client
│   │   ├── ingest_service.py  # Chunking + ChromaDB
│   │   └── rag_service.py     # RAG + Llama via Ollama
│   ├── Dockerfile
│   └── requirements.txt
├── .github/
│   └── workflows/
│       ├── ci.yml            # Tests + lint + Docker build
│       └── auto-ingest.yml   # Re-ingest on push/issues/PRs
├── docker-compose.yml
└── README.md
```
